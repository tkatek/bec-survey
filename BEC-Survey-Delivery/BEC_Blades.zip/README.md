# BEC Blade Design Package

This ZIP contains the original Laravel Blade templates and the frontend files used by the Boston English Center Conversation Room Survey.

Main student files:
- resources/views/conversation-room/create.blade.php
- resources/views/conversation-room/partials/question.blade.php
- resources/views/conversation-room/sections/*.blade.php
- resources/views/conversation-room/thank-you.blade.php

Main administrator files:
- resources/views/dashboard.blade.php
- resources/views/admin/common-answers.blade.php
- resources/views/admin/questions/index.blade.php
- resources/views/admin/reports/analytics.blade.php
- resources/views/auth/login.blade.php
- resources/views/layouts/*.blade.php
- resources/views/components/**/*.blade.php

Frontend dependencies included:
- resources/css/app.css
- resources/js/*.js
- public/images/conversation-room/*
- package.json and Vite/Tailwind/PostCSS configuration files

These templates are not standalone HTML. They require the Laravel application, its routes, controllers, services, database models, Vite build process, authentication, and configured environment for full functionality. No environment file, credentials, database records, private keys, vendor packages, node_modules, or logs are included.